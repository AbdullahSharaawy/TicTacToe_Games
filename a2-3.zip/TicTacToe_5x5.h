#ifndef _TicTacToe_5x5_H
#define _TicTacToe_5x5_H
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cctype>
#include "BoardGame_Classes.h"

using namespace std;

template <typename T>
class TicTacToe_Board : public Board<T> {
public:
    TicTacToe_Board();
    bool update_board(int x, int y, T symbol) override;
    void display_board() override;
    bool is_win() override;
    bool is_draw() override;
    bool game_is_over() override;
    void set_players(Player<T>* player1, Player<T>* player2) {
        this->players[0] = player1;
        this->players[1] = player2;
    }
    int x_count(); 
    int o_count();

private:
    T board[5][5];
    int n_moves;
    Player<T>* players[2]; 
    int current_player;
};

template <typename T>
class TicTacToe_Player : public Player<T> {

public:
    TicTacToe_Player(string name, T symbol) : Player<T>(name, symbol) {}
    void getmove(int& x, int& y) override;
};

template <typename T>
class TicTacToe_Random_Player : public Player<T> {

public:
    
    TicTacToe_Random_Player(T symbol) : Player<T>("Computer", symbol)
        { srand(static_cast<unsigned int>(time(0))); }
    
    void getmove(int& x, int& y) override;

private:
    int dimension;
};

template <typename T>
TicTacToe_Board<T>::TicTacToe_Board() {
    this->n_moves = 0;
    this->current_player = 0;
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            this->board[i][j] = 0;
        }
    }
}

template <typename T>
bool TicTacToe_Board<T>::update_board(int x, int y, T symbol) {
    if (x >= 0 && x < 5 && y >= 0 && y < 5 && this->board[x][y] == 0) {
        this->board[x][y] = toupper(symbol);
        this->n_moves++;
        return true;
    }
    return false;
}

template <typename T>
void TicTacToe_Board<T>::display_board() {
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            cout << " " << (this->board[i][j] == 0 ? " " : string(1, this->board[i][j])) << " ";
            if (j < 4) cout << "|";
        }
        cout << endl;
        if (i < 4) cout << "---+---+---+---+---\n";
    }
    cout << endl;
}

template <typename T>
int TicTacToe_Board<T>::x_count() {
    int count = 0;
    
    if (this->n_moves != 24) {
        return count;  
    }
    
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 3; j++ ) {
            if (this->board[i][j] == 'X' && this->board[i][j+1] == 'X' && this->board[i][j+2] == 'X') {
                count++;
            }
        }
    }

    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 3; j++ ) {
            if (this->board[j][i] == 'X' && this->board[j+1][i] == 'X' && this->board[j+2][i] == 'X') {
                count++;
            }
        }
    }

    for (int i = 0; i < 3 ; i++ ) {
        if (this->board[i][i] == 'X' && this->board[i+1][i+1] == 'X' && this->board[i+2][i+2] == 'X') {
            count++;
        }
    }

    for(int i=0 ; i<2 ; i++ ){
        if (this->board[1+i][i] == 'X' && this->board[i+2][i+1] == 'X' && this->board[i+3][i+2] == 'X') {
            count++;
        }
    }
    
    for(int i=0 ; i<2 ; i++ ){
        if (this->board[i][i+1] == 'X' && this->board[i+1][i+2] == 'X' && this->board[i+2][i+3] == 'X') {
            count++;
        }
    }
    
        if (this->board[0][4] == 'X' && this->board[1][3] == 'X' && this->board[2][2] == 'X') 
           count++;
        
        if (this->board[1][3] == 'X' && this->board[2][2] == 'X' && this->board[3][1] == 'X') 
           count++;
    
        if (this->board[2][2] == 'X' && this->board[3][1] == 'X' && this->board[4][0] == 'X') 
           count++;
    
        if (this->board[2][0] == 'X' && this->board[3][1] == 'X' && this->board[4][2] == 'X') 
           count++;
    
        if (this->board[0][2] == 'X' && this->board[1][3] == 'X' && this->board[2][4] == 'X') 
           count++;

        if (this->board[1][4] == 'X' && this->board[2][3] == 'X' && this->board[3][2] == 'X') 
           count++;
        
        if (this->board[2][3] == 'X' && this->board[3][2] == 'X' && this->board[4][1] == 'X') 
           count++;
        
        if (this->board[2][4] == 'X' && this->board[3][3] == 'X' && this->board[4][2] == 'X') 
           count++;
           
        if (this->board[0][3] == 'X' && this->board[1][2] == 'X' && this->board[2][1] == 'X') 
           count++;   
        
        if (this->board[1][2] == 'X' && this->board[2][1] == 'X' && this->board[3][0] == 'X') 
           count++;
        
        if (this->board[0][2] == 'X' && this->board[1][1] == 'X' && this->board[2][0] == 'X') 
           count++;
        
    return count;
}

template <typename T>
int TicTacToe_Board<T>::o_count(){
    int count = 0;
    
    if (this->n_moves != 24) {
        return count;  
    }
    
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 3; j++ ) {
            if (this->board[i][j] == 'O' && this->board[i][j+1] == 'O' && this->board[i][j+2] == 'O') {
                count++;
            }
        }
    }

    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 3; j++ ) {
            if (this->board[j][i] == 'O' && this->board[j+1][i] == 'O' && this->board[j+2][i] == 'O') {
                count++;
            }
        }
    }

    for (int i = 0; i < 3 ; i++ ) {
        if (this->board[i][i] == 'O' && this->board[i+1][i+1] == 'O' && this->board[i+2][i+2] == 'O') {
            count++;
        }
    }

    for(int i=0 ; i<2 ; i++ ){
        if (this->board[1+i][i] == 'O' && this->board[i+2][i+1] == 'O' && this->board[i+3][i+2] == 'O') {
            count++;
        }
    }
    
    for(int i=0 ; i<2 ; i++ ){
        if (this->board[i][i+1] == 'O' && this->board[i+1][i+2] == 'O' && this->board[i+2][i+3] == 'O') {
            count++;
        }
    }
    
        if (this->board[0][4] == 'O' && this->board[1][3] == 'O' && this->board[2][2] == 'O') 
           count++;
        
        if (this->board[1][3] == 'O' && this->board[2][2] == 'O' && this->board[3][1] == 'O') 
           count++;
    
        if (this->board[2][2] == 'O' && this->board[3][1] == 'O' && this->board[4][0] == 'O') 
           count++;
    
        if (this->board[2][0] == 'O' && this->board[3][1] == 'O' && this->board[4][2] == 'O') 
           count++;
    
        if (this->board[0][2] == 'O' && this->board[1][3] == 'O' && this->board[2][4] == 'O') 
           count++;

        if (this->board[1][4] == 'O' && this->board[2][3] == 'O' && this->board[3][2] == 'O') 
           count++;
        
        if (this->board[2][3] == 'O' && this->board[3][2] == 'O' && this->board[4][1] == 'O') 
           count++;
        
        if (this->board[2][4] == 'O' && this->board[3][3] == 'O' && this->board[4][2] == 'O') 
           count++;
           
        if (this->board[0][3] == 'O' && this->board[1][2] == 'O' && this->board[2][1] == 'O') 
           count++;   
        
        if (this->board[1][2] == 'O' && this->board[2][1] == 'O' && this->board[3][0] == 'O') 
           count++;
        
        if (this->board[0][2] == 'O' && this->board[1][1] == 'O' && this->board[2][0] == 'O') 
           count++;
        
        return count;
}

template <typename T>
bool TicTacToe_Board<T>::is_win() {
    int x = x_count();
    int o = o_count();
    if (x > o) {
        return true;
      } 
      
    else if (o > x) {
        return true;
      }
      
    else {
    return false;
    }
}


template <typename T>
bool TicTacToe_Board<T>::is_draw() {
    return (this->n_moves == 24 && !is_win());
}

template <typename T>
bool TicTacToe_Board<T>::game_is_over() {
    return is_win() || is_draw();
}

template <typename T>
void TicTacToe_Player<T>::getmove(int& x, int& y) {
    cout << "\n" << this->getname() << ", Please enter your move (x y): ";
    cin >> x >> y;
}

template <typename T>
void TicTacToe_Random_Player<T>::getmove(int& x, int& y) {
    x = rand() % 5;
    y = rand() % 5;
}

#endif
