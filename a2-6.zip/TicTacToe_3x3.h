#ifndef _TicTacToe_3x3_H
#define _TicTacToe_3x3_H
#include <utility>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <cctype>
#include "BoardGame_Classes.h"

using namespace std;

extern Player<char>* name[2];

template <typename T>
class TicTacToe_Board : public Board<T> {

public:
    TicTacToe_Board();
    bool update_board(int x, int y, T symbol) override;
    void display_board() override;
    bool is_win() override;
    bool is_draw() override;
    bool game_is_over() override;
    void swap_players();
    void set_players(Player<T>* player1, Player<T>* player2) {
        this->players[0] = player1;
        this->players[1] = player2;
    }
private:
    T board[3][3];
    int n_moves;
    Player<T>* players[2];
    int current_player;
};

template <typename T>
class TicTacToe_Player : public Player<T> {

public:
    TicTacToe_Player(string name, T symbol) : Player<T>(name, symbol) {}
    void getmove(int& x, int& y) override;
};

template <typename T>
class TicTacToe_Random_Player : public Player<T> {

public:
    TicTacToe_Random_Player(T symbol) : Player<T>("Computer", symbol)
        { srand(static_cast<unsigned int>(time(0))); }
    
    void getmove(int& x, int& y) override;
};

template <typename T>
TicTacToe_Board<T>::TicTacToe_Board() {
    this->n_moves = 0;
    this->current_player = 0;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            this->board[i][j] = 0;
        }
    }
}

template <typename T>
bool TicTacToe_Board<T>::update_board(int x, int y, T symbol) {
    if (x >= 0 && x < 3 && y >= 0 && y < 3 && this->board[x][y] == 0) {
        this->board[x][y] = toupper(symbol);
        this->n_moves++;
        return true;
    }
    return false;
}

template <typename T>
void TicTacToe_Board<T>::display_board() {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << " " << (this->board[i][j] == 0 ? " " : string(1, this->board[i][j])) << " ";
            if (j < 2) cout << "|";
        }
        cout << endl;
        if (i < 2) cout << "---+---+---\n";
    }
    cout << endl;
}

template <typename T>
bool TicTacToe_Board<T>::is_win() {
    for (int i = 0; i < 3; i++) {
        if (this->board[i][0] == this->board[i][1] && this->board[i][1] == this->board[i][2] && this->board[i][0] != 0)
            goto check_winner;
        if (this->board[0][i] == this->board[1][i] && this->board[1][i] == this->board[2][i] && this->board[0][i] != 0)
            goto check_winner;
    }
    if (this->board[0][0] == this->board[1][1] && this->board[1][1] == this->board[2][2] && this->board[0][0] != 0)
        goto check_winner;
    if (this->board[0][2] == this->board[1][1] && this->board[1][1] == this->board[2][0] && this->board[0][2] != 0)
        goto check_winner;

    return false;

check_winner:
    if (name[0]->getsymbol() == toupper(this->board[0][0]) || 
        name[1]->getsymbol() == toupper(this->board[1][1])) {
        swap(name[0], name[1]);
    }
    return true;
}

template <typename T>
bool TicTacToe_Board<T>::is_draw() {
    return (this->n_moves == 9 && !is_win());
}

template <typename T>
bool TicTacToe_Board<T>::game_is_over() {
       
    return is_win() || is_draw();
    
}

template <typename T>
void TicTacToe_Player<T>::getmove(int& x, int& y) {
    cout << "\n" << this->getname() << ", Please enter your move (x y): ";
    cin >> x >> y;
}

template <typename T>
void TicTacToe_Random_Player<T>::getmove(int& x, int& y) {
    x = rand() % 3;
    y = rand() % 3;
}

#endif
